// Creates a class for Moes that tracks the number of customers, numbers of burritos sold
//the price of the burritos, and the total earnings from the burritos sold.

public class Moes {
    private int customerCount;
    private int numberOfBurritoSales;
    private double burritoPrice;
    private double totalEarnings;

    //Constructor for Moes
    public Moes(int customerCount, int numberOfBurritoSales, double burritoPrice, double totalEarnings) {
        this.customerCount = customerCount;
        this.numberOfBurritoSales = numberOfBurritoSales;
        this.burritoPrice = burritoPrice;
        this.totalEarnings = totalEarnings;
    }
    //Overloaded constructor to account for lack of details
    public Moes(){
        this.customerCount = 0;
        this.numberOfBurritoSales = 0;
        this.burritoPrice = 10;
        this.totalEarnings = 0;
    }
    //Getters and Setters
    public int getCustomerCount() {
        return customerCount;
    }
    public void setCustomerCount(int customerCount) {
        this.customerCount = customerCount;
    }
    public int getNumberOfBurritoSales() {
        return numberOfBurritoSales;
    }
    public void setNumberOfBurritoSales(int numberOfBurritoSales) {
        this.numberOfBurritoSales = numberOfBurritoSales;
    }
    public double getBurritoPrice() {
        return burritoPrice;
    }
    public void setBurritoPrice(double burritoPrice) {
        this.burritoPrice = burritoPrice;
    }
    public double getTotalEarnings() {
        return totalEarnings;
    }
    public void setTotalEarnings(double totalEarnings) {
        this.totalEarnings = totalEarnings;
    }
    //Custom Method: Increases customer count and the total earnings
    public void updateSalesNumbers(){
        this.customerCount++;
        this.numberOfBurritoSales++;
        this.totalEarnings = customerCount * burritoPrice;
    }
    //Greets the customers like when you enter any Moe's location.
    public void greeting(){
        System.out.println("(ALL OF THE STAFF IN UNISON) WELCOME TO MOES!!!");
    }
    //Prints the current stats that like the customer count, number of burritos sold,
    //number of burritos sold, and the total earnings from the burritos sold.
    public void printStats(){
        System.out.println("Customer Count: " + customerCount + " with " + numberOfBurritoSales + " burritos sold.");
        System.out.println("Total Earnings: " + totalEarnings + " with the burrito price set to " +  burritoPrice);
    }
}
