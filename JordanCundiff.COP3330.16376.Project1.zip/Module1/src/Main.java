//Name: Jordan Cundiff
//Course: COP-3330C-16376
//Due Date: 08/31/2025

//Program Objective:
//This program creates classes for two separate restaurants with unique
//attributes and custom methods designed for the classes. These methods either
//output a greeting, stats, increase sales numbers, and even the customer counts.

//Inputs and Outputs:
//This program takes in specific details that fit the class including a name for the cashier, total earnings,
//prices for products, and prices. It outputs sales numbers based on the number sold, as well as the number of
//customers handled.

public class Main {
    public static void main(String[] args) {

        McDonalds mcDonalds = new McDonalds(0, "McCrispy", "Jay");
        mcDonalds.greet();
        System.out.println();
        mcDonalds.printStats();
        mcDonalds.increaseCustomerCount();
        System.out.println();
        mcDonalds.printStats();
        System.out.println();
        mcDonalds.increaseCustomerCount();
        McDonalds mcDonalds2 = new McDonalds();
        mcDonalds2.printStats();
        System.out.println();

        Moes moes = new Moes();
        moes.greeting();
        Moes moes2 = new Moes(3, 3, 10.00, 30);
        System.out.println();
        moes2.printStats();
        System.out.println();
        moes2.updateSalesNumbers();
        System.out.println();
        moes2.printStats();
        System.out.println();
        moes.updateSalesNumbers();
        System.out.println();
        moes.printStats();
    }
}