//Creates a class for McDonalds that will track the number of customers, offer preset specials,
//and track the cashiers name


public class McDonalds {
    private int customerCount;
    private String advertItem;
    private String cashier;

    //Constructor
    public McDonalds(int customerCount, String advertItem, String cashier) {
        this.customerCount = customerCount;
        this.advertItem = advertItem;
        this.cashier = cashier;
    }
    //Overloaded constructor to account for lack of details
    public McDonalds() {
        this.customerCount = 0;
        this.advertItem = "Big Mac";
        this.cashier = "Ronald";
    }
    //Getters and Setters
    public int getCustomerCount() {
        return customerCount;
    }
    public void setCustomerCount(int customerCount) {
        this.customerCount = customerCount;
    }
    public String getAdvertItem() {
        return advertItem;
    }
    public void setAdvertItem(String advertItem) {

    }
    public String getCashier() {
        return cashier;
    }
    public void setCashier(String cashier) {
        this.cashier = cashier;
    }

    //Custom Method: Increase Customer Count
    public void increaseCustomerCount() {
        this.customerCount++;
    }
    //Prints out the stats of the cashier
    public void printStats() {
        System.out.println("Cashier: " + cashier + " has helped: " + customerCount + " customers and offered the " + advertItem +" to them.");
    }
    //Prints a greeting saying the cashiers name, and mentioning the featured item for the day
    public void greet(){
        System.out.println("Welcome to McDonalds! My name is " + cashier + " would you like to try our " + advertItem + " today? Order when you're ready");
    }
}
